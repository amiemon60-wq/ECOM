# Alzooz.ae

UAE electronics marketplace — Phase 1 scaffold (architecture approved).

## Push this to your GitHub

```bash
# 1. Unzip this archive, then from inside the alzooz/ folder:
git init
git add .
git commit -m "Phase 1: architecture scaffold + Prisma schema"

# 2. Create an empty repo on GitHub first (github.com/new — don't
#    initialize it with a README, or the push below will conflict).
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

If you use SSH instead of HTTPS for GitHub, swap the remote URL for
`git@github.com:<your-username>/<your-repo>.git`.

## About your GoDaddy domain (alzooz.ae)

A couple of things worth knowing before you connect it:

- **This scaffold isn't deployable yet.** It's the Phase 1 architecture —
  database schema and project structure. There's no running app to point
  a domain at until the frontend/backend apps are built out.
- **GoDaddy is only useful here as your registrar/DNS host**, not as
  hosting. The architecture calls for Cloudflare in front of everything
  (CDN/WAF) with the actual apps deployed on Cloudflare Pages/Vercel
  (frontend) and a container host like Railway/Fly.io/AWS (backend). The
  usual path: keep alzooz.ae registered at GoDaddy, but point its
  nameservers at Cloudflare, then manage DNS records from Cloudflare.
- Once Phase 1–3 produce a working storefront, connecting the domain is
  a DNS step (CNAME/A record to whatever host you deploy to) — that part
  is quick once there's something live to point at.

## Repo layout

```
apps/
  api/      NestJS backend (auth, catalog, orders, ... — built out phase by phase)
  web/      Next.js customer storefront
packages/
  db/       Prisma schema (full marketplace schema, see prisma/schema.prisma)
  ui/       Shared design system components
  types/    Shared TypeScript types/DTOs
```

See the full architecture doc for the reasoning behind every choice here.
