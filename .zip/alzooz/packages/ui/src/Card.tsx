import * as React from "react";

export function Card({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      {...props}
      style={{
        background: "var(--color-bg)",
        border: "1px solid var(--color-border)",
        borderRadius: "var(--radius-lg)",
        padding: "var(--space-4)",
      }}
    >
      {children}
    </div>
  );
}

export interface ProductCardProps {
  name: string;
  imageUrl?: string;
  price: number;
  currency?: string;
  sellerName?: string;
  rating?: number;
}

/**
 * Marketplace-aware product card: shows the lowest current offer price
 * and (optionally) which seller it's from, since a single product can
 * have multiple seller offers — see the seller_offers architecture.
 */
export function ProductCard({
  name,
  imageUrl,
  price,
  currency = "AED",
  sellerName,
  rating,
}: ProductCardProps) {
  return (
    <Card>
      {imageUrl && (
        <img
          src={imageUrl}
          alt={name}
          style={{ width: "100%", borderRadius: "var(--radius-md)" }}
        />
      )}
      <h3 style={{ fontSize: "1rem", margin: "var(--space-2) 0" }}>{name}</h3>
      <p style={{ color: "var(--color-brand)", fontWeight: 700 }}>
        {currency} {price.toFixed(2)}
      </p>
      {sellerName && (
        <p style={{ color: "var(--color-text-muted)", fontSize: "0.85rem" }}>
          Sold by {sellerName}
        </p>
      )}
      {rating !== undefined && (
        <p style={{ color: "var(--color-accent)", fontSize: "0.85rem" }}>
          {"★".repeat(Math.round(rating))} {rating.toFixed(1)}
        </p>
      )}
    </Card>
  );
}
