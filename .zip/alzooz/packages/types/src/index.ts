// Matches the API error/success envelope defined in the architecture doc
// (section 41). Both apps/api and apps/web import these so the contract
// can't drift silently.

export interface ApiSuccess<T> {
  success: true;
  data: T;
}

export interface ApiError {
  success: false;
  error: {
    code: string;
    message: string;
  };
}

export type ApiResponse<T> = ApiSuccess<T> | ApiError;

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

export interface ProductOfferSummary {
  sellerOfferId: string;
  sellerName: string;
  price: number;
  salePrice?: number;
  condition: "NEW" | "REFURBISHED" | "USED";
  warrantyMonths: number;
  deliveryEstimateDays?: number;
  inStock: boolean;
}
