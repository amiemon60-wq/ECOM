import { PrismaClient } from "@prisma/client";

// Single shared Prisma instance — reused across the Nest app via DI (see
// apps/api/src/prisma/prisma.service.ts) rather than instantiated per-request.
declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

export const prisma = global.__prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") {
  global.__prisma = prisma;
}

export * from "@prisma/client";
