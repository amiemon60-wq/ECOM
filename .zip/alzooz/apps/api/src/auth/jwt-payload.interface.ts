export interface JwtPayload {
  sub: string; // user id
  audience: "customer" | "seller" | "admin";
  sellerId?: string; // present only for seller-portal tokens
  permissions: string[];
}
