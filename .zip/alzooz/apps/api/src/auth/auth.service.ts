import {
  ConflictException,
  Injectable,
  UnauthorizedException,
} from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { ConfigService } from "@nestjs/config";
import * as argon2 from "argon2";
import { randomUUID } from "crypto";
import { PrismaService } from "../prisma/prisma.service";
import { RegisterDto } from "./dto/register.dto";
import { LoginDto } from "./dto/login.dto";
import { JwtPayload } from "./jwt-payload.interface";

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwt: JwtService,
    private config: ConfigService,
  ) {}

  async register(dto: RegisterDto) {
    const existing = await this.prisma.client.user.findUnique({
      where: { email: dto.email },
    });
    if (existing) {
      throw new ConflictException("An account with this email already exists");
    }

    const passwordHash = await argon2.hash(dto.password);

    const user = await this.prisma.client.user.create({
      data: {
        email: dto.email,
        phone: dto.phone,
        passwordHash,
        roles: {
          create: {
            role: {
              connectOrCreate: {
                where: { name: "customer" },
                create: { name: "customer" },
              },
            },
          },
        },
        customer: { create: {} },
      },
    });

    return this.issueTokens(user.id, "customer");
  }

  async login(dto: LoginDto) {
    const user = await this.prisma.client.user.findUnique({
      where: { email: dto.email },
    });

    // Same error for "no such user" and "wrong password" — don't let the
    // response shape leak which one it was.
    if (!user) throw new UnauthorizedException("Invalid credentials");

    const valid = await argon2.verify(user.passwordHash, dto.password);
    if (!valid) throw new UnauthorizedException("Invalid credentials");

    return this.issueTokens(user.id, "customer");
  }

  /**
   * Builds an access + refresh token pair scoped to a specific audience
   * (customer/seller/admin). A customer token cannot be replayed against
   * seller or admin routes even if a permission code happens to overlap,
   * because guards also check audience where relevant.
   */
  private async issueTokens(
    userId: string,
    audience: JwtPayload["audience"],
    sellerId?: string,
  ) {
    const permissions = await this.loadPermissions(userId);

    const payload: JwtPayload = {
      sub: userId,
      audience,
      sellerId,
      permissions,
    };

    const accessToken = this.jwt.sign(payload, {
      secret: this.config.getOrThrow("JWT_ACCESS_SECRET"),
      expiresIn: this.config.get("JWT_ACCESS_TTL", "15m"),
    });

    const refreshTokenValue = randomUUID();
    const refreshTokenHash = await argon2.hash(refreshTokenValue);

    await this.prisma.client.refreshToken.create({
      data: {
        userId,
        tokenHash: refreshTokenHash,
        audience,
        expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30), // 30d
      },
    });

    return { accessToken, refreshToken: refreshTokenValue };
  }

  private async loadPermissions(userId: string): Promise<string[]> {
    const roles = await this.prisma.client.userRole.findMany({
      where: { userId },
      include: { role: { include: { permissions: { include: { permission: true } } } } },
    });

    const codes = new Set<string>();
    for (const ur of roles) {
      for (const rp of ur.role.permissions) {
        codes.add(rp.permission.code);
      }
    }
    return Array.from(codes);
  }
}
