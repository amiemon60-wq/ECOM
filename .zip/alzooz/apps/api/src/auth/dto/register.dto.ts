import { IsEmail, IsOptional, IsPhoneNumber, MinLength } from "class-validator";

export class RegisterDto {
  @IsEmail()
  email: string;

  @IsOptional()
  @IsPhoneNumber("AE")
  phone?: string;

  @MinLength(10, { message: "Password must be at least 10 characters" })
  password: string;
}
