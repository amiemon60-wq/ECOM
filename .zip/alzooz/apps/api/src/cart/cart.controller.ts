import { Body, Controller, Delete, Get, Param, Post } from "@nestjs/common";
import { CartService } from "./cart.service";
import { AddCartItemDto } from "./dto/add-cart-item.dto";
import { CurrentUser } from "../common/decorators/current-user.decorator";

interface AuthedUser {
  userId: string;
}

// No @Public() here — the default JwtAuthGuard applies, so every route
// requires a valid customer token. getOrCreateCart also scopes every
// query to that authenticated customer's own cart.
@Controller("api/cart")
export class CartController {
  constructor(private cartService: CartService) {}

  @Get()
  async getCart(@CurrentUser() user: AuthedUser) {
    const data = await this.cartService.getCart(user.userId);
    return { success: true, data };
  }

  @Post("items")
  async addItem(@CurrentUser() user: AuthedUser, @Body() dto: AddCartItemDto) {
    const data = await this.cartService.addItem(
      user.userId,
      dto.sellerOfferId,
      dto.quantity,
    );
    return { success: true, data };
  }

  @Delete("items/:id")
  async removeItem(@CurrentUser() user: AuthedUser, @Param("id") id: string) {
    const data = await this.cartService.removeItem(user.userId, id);
    return { success: true, data };
  }
}
