import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";

@Injectable()
export class CartService {
  constructor(private prisma: PrismaService) {}

  private async getOrCreateCart(userId: string) {
    const customer = await this.prisma.client.customer.findUnique({
      where: { userId },
    });
    if (!customer) throw new NotFoundException("Customer profile not found");

    let cart = await this.prisma.client.cart.findFirst({
      where: { customerId: customer.id },
      orderBy: { createdAt: "desc" },
    });

    if (!cart) {
      cart = await this.prisma.client.cart.create({
        data: { customerId: customer.id },
      });
    }

    return cart;
  }

  async addItem(userId: string, sellerOfferId: string, quantity: number) {
    const offer = await this.prisma.client.sellerOffer.findUnique({
      where: { id: sellerOfferId },
      include: { inventory: true },
    });
    if (!offer || offer.status !== "ACTIVE") {
      throw new NotFoundException("This offer is no longer available");
    }

    const availableStock = offer.inventory.reduce(
      (sum, i) => sum + (i.availableQty - i.reservedQty),
      0,
    );
    if (availableStock < quantity) {
      throw new BadRequestException("Not enough stock for the requested quantity");
    }

    const cart = await this.getOrCreateCart(userId);

    const existing = await this.prisma.client.cartItem.findFirst({
      where: { cartId: cart.id, sellerOfferId },
    });

    if (existing) {
      return this.prisma.client.cartItem.update({
        where: { id: existing.id },
        data: { quantity: existing.quantity + quantity },
      });
    }

    return this.prisma.client.cartItem.create({
      data: { cartId: cart.id, sellerOfferId, quantity },
    });
  }

  async removeItem(userId: string, cartItemId: string) {
    const cart = await this.getOrCreateCart(userId);
    await this.prisma.client.cartItem.deleteMany({
      where: { id: cartItemId, cartId: cart.id }, // scoped to this user's cart
    });
    return { removed: true };
  }

  /**
   * Returns the cart grouped by seller — the shape the checkout page and
   * seller_orders split both depend on — with live price/stock
   * re-validated against seller_offers rather than trusting whatever
   * price was cached when the item was added.
   */
  async getCart(userId: string) {
    const cart = await this.getOrCreateCart(userId);

    const items = await this.prisma.client.cartItem.findMany({
      where: { cartId: cart.id },
      include: {
        offer: {
          include: {
            seller: { select: { id: true, companyName: true } },
            variant: { include: { product: true, images: { take: 1 } } },
            inventory: true,
          },
        },
      },
    });

    const bySeller = new Map<string, any>();
    for (const item of items) {
      const sellerId = item.offer.seller.id;
      if (!bySeller.has(sellerId)) {
        bySeller.set(sellerId, {
          sellerId,
          sellerName: item.offer.seller.companyName,
          items: [],
          subtotal: 0,
        });
      }
      const currentPrice = Number(item.offer.salePrice ?? item.offer.price);
      const availableStock = item.offer.inventory.reduce(
        (sum, i) => sum + (i.availableQty - i.reservedQty),
        0,
      );
      const group = bySeller.get(sellerId);
      group.items.push({
        cartItemId: item.id,
        productName: item.offer.variant.product.nameEn,
        quantity: item.quantity,
        unitPrice: currentPrice,
        lineTotal: currentPrice * item.quantity,
        stockAvailable: availableStock,
        stockOk: availableStock >= item.quantity,
      });
      group.subtotal += currentPrice * item.quantity;
    }

    const groups = Array.from(bySeller.values());
    const subtotal = groups.reduce((sum, g) => sum + g.subtotal, 0);

    return { sellerGroups: groups, subtotal };
  }
}
