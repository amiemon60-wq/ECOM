import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  Logger,
} from "@nestjs/common";
import { Response } from "express";

/**
 * Enforces the consistent { success, error: { code, message } } shape and
 * ensures internal errors (stack traces, DB error text) never reach the
 * client — only a generic message does. Full detail still goes to the
 * server log for debugging.
 */
@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private readonly logger = new Logger("ExceptionFilter");

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();

    const isHttp = exception instanceof HttpException;
    const status = isHttp
      ? exception.getStatus()
      : HttpStatus.INTERNAL_SERVER_ERROR;

    const message = isHttp
      ? exception.message
      : "An unexpected error occurred";

    const code = isHttp
      ? (exception.getResponse() as any)?.code ?? "ERROR"
      : "INTERNAL_ERROR";

    if (!isHttp) {
      // Full detail logged server-side only.
      this.logger.error(exception);
    }

    response.status(status).json({
      success: false,
      error: { code, message },
    });
  }
}
