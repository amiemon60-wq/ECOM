import { createParamDecorator, ExecutionContext } from "@nestjs/common";

/**
 * Pulls the authenticated user object (set by JwtStrategy.validate) off
 * the request. Use this instead of reading req.user directly so the
 * shape stays centralized in one place.
 */
export const CurrentUser = createParamDecorator(
  (_: unknown, ctx: ExecutionContext) => {
    const request = ctx.switchToHttp().getRequest();
    return request.user;
  },
);
