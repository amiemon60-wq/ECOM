import { SetMetadata } from "@nestjs/common";

export const IS_PUBLIC_KEY = "is_public";

/**
 * Marks a route as not requiring authentication. Catalog browsing
 * (categories, products, search) is public; cart/checkout/account routes
 * are not decorated and fall through to the default JwtAuthGuard.
 */
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);
