import { SetMetadata } from "@nestjs/common";

export const PERMISSION_KEY = "required_permission";

/**
 * Declares the permission code a route requires, e.g.:
 *
 *   @RequirePermission('order.refund')
 *   @Post(':id/refund')
 *   refundOrder(...) { ... }
 *
 * Enforced by PermissionsGuard — checked server-side against the
 * authenticated user's roles on every request. Never trust a client-
 * supplied role claim instead of this.
 */
export const RequirePermission = (permissionCode: string) =>
  SetMetadata(PERMISSION_KEY, permissionCode);
