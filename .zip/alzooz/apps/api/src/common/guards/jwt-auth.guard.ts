import { ExecutionContext, Injectable } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import { AuthGuard } from "@nestjs/passport";
import { IS_PUBLIC_KEY } from "../decorators/public.decorator";

/**
 * Verifies the JWT access token (see JwtStrategy). This alone only proves
 * *who* the caller is — see PermissionsGuard for *what* they're allowed
 * to do, and audience checks in JwtStrategy for *which* app surface
 * (customer/seller/admin) the token was issued for.
 *
 * Routes marked @Public() (catalog browsing, auth register/login) skip
 * this check entirely.
 */
@Injectable()
export class JwtAuthGuard extends AuthGuard("jwt") {
  constructor(private reflector: Reflector) {
    super();
  }

  canActivate(context: ExecutionContext) {
    const isPublic = this.reflector.get<boolean>(
      IS_PUBLIC_KEY,
      context.getHandler(),
    );
    if (isPublic) return true;
    return super.canActivate(context);
  }
}
