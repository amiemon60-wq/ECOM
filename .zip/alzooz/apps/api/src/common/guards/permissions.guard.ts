import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
} from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import { PERMISSION_KEY } from "../decorators/require-permission.decorator";

/**
 * Runs after JwtAuthGuard. Reads the permission code declared via
 * @RequirePermission(...) and checks it against the permissions attached
 * to the authenticated user's roles (loaded onto req.user by JwtStrategy).
 *
 * Routes with no @RequirePermission decorator are allowed through once
 * authenticated — apply @RequirePermission explicitly on every route that
 * touches another party's data (seller data, other customers' orders, etc).
 */
@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredPermission = this.reflector.get<string | undefined>(
      PERMISSION_KEY,
      context.getHandler(),
    );

    if (!requiredPermission) return true;

    const request = context.switchToHttp().getRequest();
    const user = request.user as { permissions?: string[] } | undefined;

    if (!user?.permissions?.includes(requiredPermission)) {
      throw new ForbiddenException(
        `Missing required permission: ${requiredPermission}`,
      );
    }

    return true;
  }
}
