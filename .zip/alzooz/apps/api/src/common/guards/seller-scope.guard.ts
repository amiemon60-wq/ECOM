import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
} from "@nestjs/common";

/**
 * Every seller-portal route that loads a resource by ID must extend/use
 * this pattern. It does NOT trust a sellerId in the request body or query
 * string — it injects the authenticated seller's own ID from the JWT and
 * the repository layer filters by it. This is what makes
 * "seller A cannot read seller B's orders/offers/ledger" true at the
 * framework level rather than something each controller has to remember.
 *
 * Usage: inject request.sellerId in services instead of accepting a
 * sellerId param from the client at all, e.g.
 *   this.offersService.findAllForSeller(request.sellerId)
 * never
 *   this.offersService.findAllForSeller(req.query.sellerId)
 */
@Injectable()
export class SellerScopeGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const user = request.user as { sellerId?: string } | undefined;

    if (!user?.sellerId) {
      throw new ForbiddenException("No seller context on this token");
    }

    // Downstream controllers/services must read request.sellerId — never
    // a client-supplied identifier — when scoping seller-portal queries.
    request.sellerId = user.sellerId;
    return true;
  }
}
