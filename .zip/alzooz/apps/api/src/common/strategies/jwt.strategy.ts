import { Injectable } from "@nestjs/common";
import { PassportStrategy } from "@nestjs/passport";
import { ExtractJwt, Strategy } from "passport-jwt";
import { ConfigService } from "@nestjs/config";
import { JwtPayload } from "./jwt-payload.interface";

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(config: ConfigService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: config.getOrThrow<string>("JWT_ACCESS_SECRET"),
    });
  }

  // Return value becomes `request.user`. We deliberately re-shape it here
  // rather than passing the raw payload through, so guards/controllers
  // have a stable, minimal contract to depend on.
  async validate(payload: JwtPayload) {
    return {
      userId: payload.sub,
      audience: payload.audience,
      sellerId: payload.sellerId,
      permissions: payload.permissions,
    };
  }
}
