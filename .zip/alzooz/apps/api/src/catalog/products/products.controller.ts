import { Controller, Get, Param, Query } from "@nestjs/common";
import { Public } from "../../common/decorators/public.decorator";
import { ProductsService } from "./products.service";
import { ProductQueryDto } from "../dto/product-query.dto";

@Public()
@Controller("api/products")
export class ProductsController {
  constructor(private productsService: ProductsService) {}

  @Get()
  async findAll(@Query() query: ProductQueryDto) {
    const data = await this.productsService.findAll(query);
    return { success: true, data };
  }

  @Get(":slug")
  async findOne(@Param("slug") slug: string) {
    const data = await this.productsService.findBySlug(slug);
    return { success: true, data };
  }
}
