import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../prisma/prisma.service";
import { ProductQueryDto } from "../dto/product-query.dto";

@Injectable()
export class ProductsService {
  constructor(private prisma: PrismaService) {}

  /**
   * Listing view: one row per product, showing only the lowest current
   * active offer price (what the customer sees on a product card). Full
   * offer comparison only loads on the product detail page — see
   * findBySlug — to keep listing queries cheap.
   */
  async findAll(query: ProductQueryDto) {
    const page = query.page ?? 1;
    const pageSize = query.pageSize ?? 24;

    const where: any = { status: "PUBLISHED" };
    if (query.category) where.category = { slug: query.category };
    if (query.brand) where.brand = { slug: query.brand };

    const products = await this.prisma.client.product.findMany({
      where,
      skip: (page - 1) * pageSize,
      take: pageSize,
      orderBy: query.sort === "newest" ? { createdAt: "desc" } : undefined,
      include: {
        brand: true,
        variants: {
          take: 1,
          include: {
            images: { take: 1, orderBy: { sortOrder: "asc" } },
            offers: {
              where: { status: "ACTIVE" },
              orderBy: { price: "asc" },
              take: 1,
            },
          },
        },
      },
    });

    // Shape each product down to what the listing card needs: name,
    // image, lowest price. Products with zero active offers are filtered
    // out — nothing sellable shouldn't appear in listings.
    const shaped = products
      .map((p) => {
        const variant = p.variants[0];
        const lowestOffer = variant?.offers[0];
        if (!lowestOffer) return null;
        return {
          id: p.id,
          slug: p.slug,
          name: p.nameEn,
          brand: p.brand?.nameEn,
          imageUrl: variant.images[0]?.r2Key,
          price: lowestOffer.salePrice ?? lowestOffer.price,
          offerCount: undefined as number | undefined, // filled below if needed
        };
      })
      .filter(Boolean);

    if (query.minPrice !== undefined) {
      return shaped.filter((p) => Number(p!.price) >= query.minPrice!);
    }
    if (query.maxPrice !== undefined) {
      return shaped.filter((p) => Number(p!.price) <= query.maxPrice!);
    }

    return shaped;
  }

  /**
   * Product detail view: full seller-offer comparison — every active
   * offer across every seller for the primary variant, sorted by price.
   * This is what powers the "3 sellers · from AED X" comparison table.
   */
  async findBySlug(slug: string) {
    const product = await this.prisma.client.product.findUnique({
      where: { slug },
      include: {
        brand: true,
        category: true,
        variants: {
          include: {
            images: { orderBy: { sortOrder: "asc" } },
            offers: {
              where: { status: "ACTIVE" },
              orderBy: { price: "asc" },
              include: {
                seller: { select: { id: true, companyName: true, rating: true } },
                inventory: true,
              },
            },
          },
        },
      },
    });

    if (!product) throw new NotFoundException("Product not found");

    return {
      ...product,
      variants: product.variants.map((v) => ({
        ...v,
        offers: v.offers.map((o) => ({
          id: o.id,
          sellerName: o.seller.companyName,
          sellerRating: o.seller.rating,
          price: o.price,
          salePrice: o.salePrice,
          condition: o.condition,
          warrantyMonths: o.warrantyMonths,
          inStock: o.inventory.some((i) => i.availableQty > i.reservedQty),
        })),
      })),
    };
  }
}
