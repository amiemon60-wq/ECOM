import { Controller, Get, Param } from "@nestjs/common";
import { Public } from "../../common/decorators/public.decorator";
import { BrandsService } from "./brands.service";

@Public()
@Controller("api/brands")
export class BrandsController {
  constructor(private brandsService: BrandsService) {}

  @Get()
  async findAll() {
    const data = await this.brandsService.findAll();
    return { success: true, data };
  }

  @Get(":slug")
  async findOne(@Param("slug") slug: string) {
    const data = await this.brandsService.findBySlug(slug);
    return { success: true, data };
  }
}
