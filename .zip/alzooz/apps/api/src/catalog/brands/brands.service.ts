import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../prisma/prisma.service";

@Injectable()
export class BrandsService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.client.brand.findMany({ orderBy: { nameEn: "asc" } });
  }

  async findBySlug(slug: string) {
    const brand = await this.prisma.client.brand.findUnique({ where: { slug } });
    if (!brand) throw new NotFoundException("Brand not found");
    return brand;
  }
}
