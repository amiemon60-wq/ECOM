import { Controller, Get, Param } from "@nestjs/common";
import { Public } from "../../common/decorators/public.decorator";
import { CategoriesService } from "./categories.service";

@Public()
@Controller("api/categories")
export class CategoriesController {
  constructor(private categoriesService: CategoriesService) {}

  @Get()
  async findAll() {
    const data = await this.categoriesService.findTree();
    return { success: true, data };
  }

  @Get(":slug")
  async findOne(@Param("slug") slug: string) {
    const data = await this.categoriesService.findBySlug(slug);
    return { success: true, data };
  }
}
