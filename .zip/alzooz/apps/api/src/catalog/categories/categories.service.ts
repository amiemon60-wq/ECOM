import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../prisma/prisma.service";

@Injectable()
export class CategoriesService {
  constructor(private prisma: PrismaService) {}

  // Top-level categories with their immediate children, for nav/homepage.
  async findTree() {
    return this.prisma.client.category.findMany({
      where: { parentId: null },
      orderBy: { sortOrder: "asc" },
      include: {
        children: { orderBy: { sortOrder: "asc" } },
      },
    });
  }

  async findBySlug(slug: string) {
    const category = await this.prisma.client.category.findUnique({
      where: { slug },
      include: { children: true, parent: true },
    });
    if (!category) throw new NotFoundException("Category not found");
    return category;
  }
}
