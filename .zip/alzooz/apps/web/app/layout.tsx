import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Alzooz.ae — Electronics Marketplace in the UAE",
  description:
    "Shop electronics, mobiles, laptops and more from Alzooz and trusted UAE sellers.",
};

// Locale/RTL note: this root layout defaults to English/LTR. The full
// i18n setup (en/ar routes, dir="rtl" per-locale) lands with the
// storefront pages in Phase 2 — this is just the Phase 1 shell so the
// app boots and the design tokens are wired up.
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" dir="ltr">
      <body>{children}</body>
    </html>
  );
}
