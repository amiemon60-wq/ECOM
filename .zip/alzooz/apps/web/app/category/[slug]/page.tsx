import { ProductCard } from "@alzooz/ui";

interface Props {
  params: { slug: string };
}

const API_URL = process.env.API_URL ?? "http://localhost:4000";

// SSR for SEO — category pages are crawlable, canonical entry points
// per the SEO architecture in the plan.
async function getProducts(categorySlug: string) {
  const res = await fetch(`${API_URL}/api/products?category=${categorySlug}`, {
    next: { revalidate: 60 },
  });
  const json = await res.json();
  return json.success ? json.data : [];
}

export default async function CategoryPage({ params }: Props) {
  const products = await getProducts(params.slug);

  return (
    <main style={{ padding: "1.5rem" }}>
      <h1 style={{ textTransform: "capitalize" }}>
        {params.slug.replace(/-/g, " ")}
      </h1>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
          gap: "var(--space-3)",
          marginTop: "var(--space-4)",
        }}
      >
        {products.map((p: any) => (
          <a key={p.id} href={`/product/${p.slug}`} style={{ textDecoration: "none" }}>
            <ProductCard name={p.name} price={Number(p.price)} />
          </a>
        ))}
      </div>

      {products.length === 0 && (
        <p style={{ color: "var(--color-text-muted)" }}>
          No products found in this category yet.
        </p>
      )}
    </main>
  );
}
