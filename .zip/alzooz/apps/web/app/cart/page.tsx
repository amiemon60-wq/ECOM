"use client";

import { useEffect, useState } from "react";
import { Card, Button } from "@alzooz/ui";

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000";

interface SellerGroup {
  sellerId: string;
  sellerName: string;
  subtotal: number;
  items: {
    cartItemId: string;
    productName: string;
    quantity: number;
    unitPrice: number;
    lineTotal: number;
    stockOk: boolean;
  }[];
}

export default function CartPage() {
  const [groups, setGroups] = useState<SellerGroup[]>([]);
  const [subtotal, setSubtotal] = useState(0);
  const [loading, setLoading] = useState(true);

  async function loadCart() {
    const token = localStorage.getItem("accessToken");
    if (!token) {
      window.location.href = "/login";
      return;
    }
    const res = await fetch(`${API_URL}/api/cart`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const json = await res.json();
    if (json.success) {
      setGroups(json.data.sellerGroups);
      setSubtotal(json.data.subtotal);
    }
    setLoading(false);
  }

  useEffect(() => {
    loadCart();
  }, []);

  async function removeItem(cartItemId: string) {
    const token = localStorage.getItem("accessToken");
    await fetch(`${API_URL}/api/cart/items/${cartItemId}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token}` },
    });
    loadCart();
  }

  if (loading) return <main style={{ padding: "1.5rem" }}>Loading your cart…</main>;

  const hasStockIssue = groups.some((g) => g.items.some((i) => !i.stockOk));

  return (
    <main style={{ padding: "1.5rem", maxWidth: 700 }}>
      <h1>Your cart</h1>

      {groups.length === 0 && <p>Your cart is empty.</p>}

      {/* Grouped by seller — each seller becomes its own seller_order at
          checkout, per the marketplace order architecture. */}
      {groups.map((group) => (
        <Card key={group.sellerId} style={{ marginBottom: "var(--space-3)" }}>
          <h3 style={{ margin: 0, fontSize: "0.9rem" }}>Sold by {group.sellerName}</h3>
          {group.items.map((item) => (
            <div
              key={item.cartItemId}
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                padding: "var(--space-2) 0",
                borderTop: "1px solid var(--color-border)",
              }}
            >
              <div>
                <p style={{ margin: 0 }}>{item.productName}</p>
                <p style={{ margin: 0, fontSize: "0.8rem", color: "var(--color-text-muted)" }}>
                  Qty {item.quantity} × AED {item.unitPrice.toFixed(2)}
                </p>
                {!item.stockOk && (
                  <p style={{ margin: 0, fontSize: "0.8rem", color: "var(--color-danger)" }}>
                    Not enough stock — please reduce quantity
                  </p>
                )}
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "var(--space-2)" }}>
                <span style={{ fontWeight: 700 }}>AED {item.lineTotal.toFixed(2)}</span>
                <Button variant="ghost" onClick={() => removeItem(item.cartItemId)}>
                  Remove
                </Button>
              </div>
            </div>
          ))}
          <p style={{ textAlign: "right", fontWeight: 700 }}>
            Subtotal: AED {group.subtotal.toFixed(2)}
          </p>
        </Card>
      ))}

      {groups.length > 0 && (
        <>
          <p style={{ fontSize: "1.1rem", fontWeight: 700 }}>
            Total: AED {subtotal.toFixed(2)}
          </p>
          <Button variant="primary" disabled={hasStockIssue}>
            Proceed to checkout
          </Button>
          {hasStockIssue && (
            <p style={{ color: "var(--color-danger)", fontSize: "0.85rem" }}>
              Resolve stock issues above before checking out.
            </p>
          )}
        </>
      )}
    </main>
  );
}
