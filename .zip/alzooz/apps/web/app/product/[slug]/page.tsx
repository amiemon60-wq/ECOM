import { OfferComparisonTable } from "./OfferComparisonTable";

interface Props {
  params: { slug: string };
}

const API_URL = process.env.API_URL ?? "http://localhost:4000";

async function getProduct(slug: string) {
  const res = await fetch(`${API_URL}/api/products/${slug}`, {
    next: { revalidate: 60 },
  });
  if (!res.ok) return null;
  const json = await res.json();
  return json.success ? json.data : null;
}

export async function generateMetadata({ params }: Props) {
  const product = await getProduct(params.slug);
  if (!product) return {};
  return {
    title: product.seoMeta?.title ?? `${product.nameEn} — Alzooz.ae`,
    description: product.seoMeta?.metaDescription ?? product.descriptionEn,
  };
}

export default async function ProductPage({ params }: Props) {
  const product = await getProduct(params.slug);

  if (!product) {
    return <main style={{ padding: "1.5rem" }}>Product not found.</main>;
  }

  const primaryVariant = product.variants[0];
  const offers = primaryVariant?.offers ?? [];

  return (
    <main style={{ padding: "1.5rem", maxWidth: 900 }}>
      <nav style={{ fontSize: "0.85rem", color: "var(--color-text-muted)" }}>
        {product.category?.nameEn} / {product.brand?.nameEn}
      </nav>

      <h1>{product.nameEn}</h1>

      {product.descriptionEn && (
        <p style={{ color: "var(--color-text-muted)" }}>{product.descriptionEn}</p>
      )}

      <h2 style={{ fontSize: "1rem", marginTop: "var(--space-5)" }}>
        {offers.length} seller{offers.length !== 1 ? "s" : ""} offering this product
      </h2>

      <OfferComparisonTable offers={offers} />

      {/* Product schema for SEO — real values once product content is
          fully populated by admin/AI-content workflows in later phases. */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Product",
            name: product.nameEn,
            description: product.descriptionEn,
            brand: product.brand?.nameEn,
          }),
        }}
      />
    </main>
  );
}
