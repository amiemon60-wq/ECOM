"use client";

import { Button } from "@alzooz/ui";

interface Offer {
  id: string;
  sellerName: string;
  sellerRating: number;
  price: number;
  salePrice?: number;
  condition: string;
  warrantyMonths: number;
  inStock: boolean;
}

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000";

/**
 * Renders every active seller offer for one product variant, sorted by
 * price (server already sorts ascending), and lets the customer add
 * whichever offer they choose to the cart — this is the marketplace
 * comparison UI the architecture doc calls out in section 2.
 */
export function OfferComparisonTable({ offers }: { offers: Offer[] }) {
  async function addToCart(sellerOfferId: string) {
    const token = localStorage.getItem("accessToken");
    if (!token) {
      window.location.href = "/login";
      return;
    }

    const res = await fetch(`${API_URL}/api/cart/items`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ sellerOfferId, quantity: 1 }),
    });

    if (res.ok) {
      window.location.href = "/cart";
    } else {
      const json = await res.json();
      alert(json.error?.message ?? "Could not add this item to your cart.");
    }
  }

  return (
    <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "var(--space-4)" }}>
      <thead>
        <tr style={{ borderBottom: "1px solid var(--color-border)", textAlign: "left" }}>
          <th style={{ padding: "var(--space-2)" }}>Seller</th>
          <th>Condition</th>
          <th>Warranty</th>
          <th>Price</th>
          <th>Stock</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {offers.map((offer) => (
          <tr key={offer.id} style={{ borderBottom: "1px solid var(--color-border)" }}>
            <td style={{ padding: "var(--space-2)" }}>
              {offer.sellerName}{" "}
              <span style={{ color: "var(--color-accent)", fontSize: "0.85rem" }}>
                ★ {offer.sellerRating}
              </span>
            </td>
            <td style={{ textTransform: "capitalize" }}>
              {offer.condition.toLowerCase()}
            </td>
            <td>{offer.warrantyMonths} months</td>
            <td style={{ fontWeight: 700, color: "var(--color-brand)" }}>
              AED {Number(offer.salePrice ?? offer.price).toFixed(2)}
            </td>
            <td style={{ color: offer.inStock ? "var(--color-success)" : "var(--color-danger)" }}>
              {offer.inStock ? "In stock" : "Out of stock"}
            </td>
            <td>
              <Button
                variant="primary"
                disabled={!offer.inStock}
                onClick={() => addToCart(offer.id)}
              >
                Add to cart
              </Button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
