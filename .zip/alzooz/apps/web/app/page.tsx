import { Button } from "@alzooz/ui";

// Phase 1 placeholder — the real homepage (hero, flash deals, featured
// categories/brands, AI assistant entry point, etc. per the architecture
// doc section 6) is built in Phase 2 once catalog data exists to render.
export default function HomePage() {
  return (
    <main style={{ padding: "2rem", fontFamily: "var(--font-sans)" }}>
      <h1 style={{ color: "var(--color-brand)" }}>ALZOOZ</h1>
      <p>UAE electronics marketplace — storefront scaffold.</p>
      <Button>Start Shopping</Button>
    </main>
  );
}
